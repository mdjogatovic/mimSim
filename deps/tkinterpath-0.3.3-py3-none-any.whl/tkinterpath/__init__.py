"""
Python implementation of tkpath 0.3.3.
"""

__version__ = "0.3.3"

import tkinter as tk
import os, sys
  
class Matrix:
    """Matrix class"""
    def __init__(self, m=[(1,0),(0,1),(0,0)]):
        self.__master = tk._get_default_root('matrix')
        self.__m = m

    def __eval(self,e):
        "Tcl statement evaluation"
        mat = []
        for r in self.__master.tk.splitlist(self.__master.tk.eval(e)):
            c1, c2 = self.__master.tk.splitlist(r)
            mat.append((self.__master.tk.getdouble(c1),self.__master.tk.getdouble(c2)))        
        return mat

    def rotate(self,angle,cx=0,cy=0):
        """Return matrix with rotation of angle around cx, cy."""
        self.__imul__(Matrix(self.__eval(f'tkp::matrix rotate {angle} {cx} {cy}')))
        return self

    def scale(self,factxy,facty=None):
        """Return scaling matrix. If sy is not provided use sx for x and y direction."""
        if facty:
            self.__imul__(Matrix(self.__eval(f'tkp::matrix scale {factxy} {facty}')))
        else:
            self.__imul__(Matrix(self.__eval(f'tkp::matrix scale {factxy}')))
        return self

    def flip(self,cx=0,cy=0,fx=1,fy=1):
        """Return matrix with translation of cx, cy and flip with fx and fy."""
        self.__imul__(Matrix(self.__eval(f'tkp::matrix flip {cx} {cy} {fx} {fy}')))
        return self

    def rotateflip(self,angle=0,cx=0,cy=0,fx=1,fy=1):
        """Return matrix with translation of cx, cy and flip with fx and fy."""
        self.__imul__(Matrix(self.__eval(f'tkp::matrix rotateflip {angle} {cx} {cy} {fx} {fy}')))
        return self

    def skewx(self,angle):
        """Return matrix with skew in x-direction of angle"""
        self.__imul__(Matrix(self.__eval(f'tkp::matrix skewx {angle}')))
        return self

    def skewy(self,angle=None):
        """Return matrix with skew in y-direction of angle"""
        self.__imul__(Matrix(self.__eval(f'tkp::matrix skewy {angle}')))
        return self

    def move(self,dx,dy):
        """Return matrix with translation of dx in x-direction and dy in y-direction."""
        self.__imul__(Matrix(self.__eval(f'tkp::matrix move {dx} {dy}')))
        return self

    def __imul__(self,m):
        """Return product of matrix multiplication of self and m."""
        self.__m = self.__eval(f'tkp::matrix mult [list {self}] [list {m}]')

    def __mul__(self,m):
        """Return product of matrix multiplication of self and m."""
        return Matrix(self.__eval(f'tkp::matrix mult [list {self}] [list {m}]'))

    def inv(self):
        """Inverse matrix"""
        a, b = self.__m[0]
        c, d = self.__m[1]
        e, f = self.__m[2]
        D = a*d-b*c
        return Matrix([(d/D,-b/D),(-c/D,a/D),((b*f-d*e)/D,-(a*f-c*e)/D)])
    
    @property
    def m(self):
        return self.__m
    
    @m.setter
    def m(self,m):
        self.__m = m

    def __str__(self):
        return str(self.__m).replace("[","").replace("]","").replace(",","").replace("(","{").replace(")","}")

class Surface:
    """Surface class."""
    def __init__(self,w,h):
        """Creates an in memory drawing surface. Its format is platform dependent. """
        self.__master = tk._get_default_root('surface')
        self.__s = self.__master.tk.eval(f'tkp::surface new {w} {h}')

    def __del__(self):
        """Destroys surface"""
        self.__master.tk.call(self.__s,'destroy')

    def create(self,type,*coords,**kw):
        """Draws the item of type to the surface. All item types except the group 
           and the corresponding options as described above are supported, 
           except the canvas specific -tags and -state."""
        self.__master.tk.call(self.__s, 'create', type,  *(coords + self.__master._options(kw)))

    def copy(self,image):
        """Copies the surface to an existing image (photo)."""
        self.__master.tk.call(self.__s,'copy',image)
        
    def names(self):
        """Lists the existing surface tokens."""
        return self.__master.tk.call(self.__s,'names')

    def erase(self,x,y,w,h):
        """Erases the indicated area to transparent."""
        self.__master.tk.call(self.__s,'erase',x,y,w,h)

    def height(self):
        """Returns height."""
        return self.__master.tk.call(self.__s,'height')

    def width(self):
        """Returns width."""
        return self.__master.tk.call(self.__s,'width')

    def __str__(self):
        return self.__s

def pixelalign():
    """The command tkp::pixelalign says how the platform graphics library draw when we specify
       integer coordinates. Some libraries position a one pixel wide line exactly at the pixel 
       boundaries, and smears it out, if antialiasing, over the adjecent pixels. This can look 
       blurred since a one pixel wide black line suddenly becomes a two pixel wide grey line.
       It seems that cairo and quartz (MacOSX) do this, while gdi+ on Windows doesn't. This 
       command just provides the info for you so you may take actions. Either you can manually 
       position lines with odd integer widths at the center of pixels (adding 0.5), or set the 
       tkp::depixelize equal to 1, see below."""
    master = tk._get_default_root('pixelalign')
    return master.tk.getint(master.tk.eval(f'tkp::pixelalign'))


def antialias(v=1):
    """Antialiasing, if available, is controlled by the function antialias. 
       To switch on pass 1 as argument (antialias(1))."""
    tk.BooleanVar(name="tkp::antialias").set(v)

def depixelize(v=1):
    """With the boolean variable tkp::depixelize equal to 1 we try to adjust coordinates for 
       objects with integer line widths"""
    tk.BooleanVar(name="tkp::depixelize").set(v)

def gradientstopsstyle(name):
    master = tk._get_default_root('gradientstopsstyle')
    stops = []
    for x in master.tk.splitlist(master.tk.eval(f'tkp::gradientstopsstyle {name}')):
        s, c = master.tk.splitlist(x)
        stops.append((master.tk.getdouble(s),c))
    return stops

def ellipse_path(x,y,rx,ry):
    """The function return a path definition of an ellipse with a middle 
       point at x and y and a radius in x-disrection of rx and a radius 
       in y-direction of ry."""
    master = tk._get_default_root('path_ellipse')
    return master.tk.eval(f'tkp::path::ellipse {x} {y} {rx} {ry}')

def circle_path(x,y,r):
    """The function return a path definition of an circle with a middle 
       point at x and y and a radius of r."""
    master = tk._get_default_root('circlepath')
    return master.tk.eval(f'tkp::path::circle {x} {y} {r}')

class Style:
    """Style class."""
    def __init__(self, master,**kw):
        """Creates a style object."""
        self.__master = master
        self.__s = master.tk.call(self.__master._w, 'style', 'create', *(master._options(kw)))

    def __del__(self):
        """Deletes the object."""
        try:
            self.__master.tk.call(self.__master._w, 'style', 'delete', self.__s)
        except:
            pass
    
    def cget(self, option):
        """Returns the value of an option."""
        return self.__master.tk.call(self.__master._w, 'style', 'cget', self.__s, '-'+option)
    
    def configure(self,**kw):
        """Configures the object in the usual tcl way."""
        self.__master.tk.call(self.__master._w, 'style', 'configure', self.__s, *(self.__master._options(kw)))

    config = configure

    @staticmethod
    def inuse(s):
        """If any item is configured with the style token 1 is returned, else 0."""
        master = tk._get_default_root('style')
        return bool(master.tk.getint(master.tk.call(master._w, 'style', 'inuse', s)))

    def names(self):
        """Returns all existing tokens."""
        master = tk._get_default_root('matrix')
        return master.tk.splitlist(self.__master.tk.call(master._w, 'style', 'names'))

    def __str__(self):
        return self.__s

class Gradient:
    """Gradient class."""
    def __init__(self, master, type ,**kw):
        """Construct a linear gradient object with type any of linear or radial and returns its token.

           The options for linear gradients are:

           -method pad|repeat|reflect

               Partial implementation; defaults to pad

           -stops {stopSpec ?stopSpec...?}

               Where stopSpec is a list {offset color ?opacity?}. All offsets must be ordered and 
               run from 0 to 1.

           -lineartransition {x1 y1 x2 y2}

               Specifies the transtion vector relative the items bounding box. Depending on -units it 
               gets interpreted differently. If -units is 'bbox' coordinates run from 0 to 1 and are 
               relative the items bounding box. If -units is 'userspace' then they are defined in absolute 
               coordinates but in the space of the items coordinate system. It defaults to {0 0 1 0}, 
               left to right.

           -matrix {{a b} {c d} {tx ty}}

               Sets a specific transformation for the gradient pattern only. NB: not sure about the order 
               transforms, see -units.

           -units bbox|userspace

               Sets the units of the transition coordinates. See above. Defaults to 'bbox'.

           The options for radial gradients are the same as for linear gradients except that the -lineartransition 
           is replaced by a -radialtransition:

           -radialtransition {cx cy ?r? ?fx fy?}

               Specifies the transition circles relative the items bounding box and run from 0 to 1. They default 
               to {0.5 0.5 0.5 0.5 0.5}. cx,cy is the center of the end circle and fx,fy the center of the start point."""
        self.__master = master
        self.__g = master.tk.call(master._w, 'gradient', 'create', type, *(master._options(kw)))

    def cget(self, option):
        """Returns the value of an option."""
        return self.__master.tk.call(self.__master._w, 'gradient', 'cget', self.__g, '-'+option)

    def configure(self, **kw):
        """Configures the object in the usual tcl way."""
        self.__master.tk.call(self.__master._w, 'gradient', 'configure', self.__g, *(self.__master._options(kw)))

    config = configure

    def __del__(self):
        """Delete gradient"""
        try:
            self.__master.tk.call(self.__master._w, 'gradient', 'delete', self.__g)
        except:
            pass
    @staticmethod
    def inuse(g):
        """If any item is configured with the gradient token 1 is returned, else 0."""
        master = tk._get_default_root('gradient')
        return master.tk.getint(master.tk.call(master._w, 'gradient', 'inuse', g))
   
    @staticmethod
    def names():
        """Returns all existing tokens."""
        master = tk._get_default_root('gradient')
        return master.tk.splitlist(master.tk.call(master._w, 'gradient', 'names'))

    def type(self):
        """Returns the type (linear|radial) of the gradient."""
        return self.__master.tk.call(self.__master._w, 'gradient', 'type', self.__g)
    
    def __str__(self):
        return self.__g
    

class Canvas(tk.Canvas):
    """Canvas widget to display graphical elements like lines or text."""
    package_loaded = False

    def __init__(self, master=None, cnf={}, **kw):
        """Construct a canvas widget with the parent MASTER.

        Valid resource names: background, bd, bg, borderwidth, closeenough,
        confine, cursor, height, highlightbackground, highlightcolor,
        highlightthickness, insertbackground, insertborderwidth,
        insertofftime, insertontime, insertwidth, offset, relief,
        scrollregion, selectbackground, selectborderwidth, selectforeground,
        state, takefocus, width, xscrollcommand, xscrollincrement,
        yscrollcommand, yscrollincrement."""
        if not Canvas.package_loaded:
            package_dir = os.path.abspath(os.path.dirname(__file__))
            if sys.maxsize>2**32:
                architecture = 'amd64'
            else:
                raise NotImplementedError('x86 version of tkpath is not implemented')
            
            tkpath_dir = os.path.join(package_dir,'tkpath0.3.3',os.name, architecture)

            current_dir = os.getcwd()
            os.chdir(tkpath_dir)

            root = master or tk._get_default_root()

            root.tk.eval("source pkgIndex.tcl")
            root.tk.eval("package require tkpath")
            root.tk.eval("source tkpath.tcl")            
            os.chdir(current_dir)
            
            Canvas.package_loaded = True

        tk.Canvas.__bases__[0].__init__(self, master, 'tkp::canvas', cnf, kw)

    def ancestors(self, tagOrId):
        """Returns a list of item id's of the first item
           matching tagOrId starting with the root item with id 0."""
        return [self.tk.getint(x) for x in self.tk.splitlist(self.tk.call(self._w, 'ancestors', tagOrId))]

    def children(self, tagOrId):
        """Lists all children of the first item matching tagOrId."""
        return [self.tk.getint(x) for x in self.tk.splitlist(self.tk.call(self._w, 'children', tagOrId))]

    def depth(self, tagOrId):
        """Returns the depth in the tree hierarchy of the first
           item matching tagOrId. The root item has depth 0 and children
           of the root has depth 1 and so on.gOrId."""
        return self.tk.getint(self.tk.call(self._w, 'depth', tagOrId))
        
    def distance(self,tagOrId,x,y):
        """Returns the closest distance between the point (x, y) and the first
           item matching tagOrId."""
        return self.tk.getdouble(self.tk.call(self._w, 'distance', tagOrId, x, y))

    def firstchild(self, tagOrId):
        """Returns the first child item of the first item matching tagOrId.
           Applies only for groups."""
        return self.tk.getint(self.tk.call(self._w, 'firstchild', tagOrId))

    def lastchild(self, tagOrId):
        """Returns the last child item of the first item matching tagOrId.
           Applies only for groups."""
        return self.tk.getint(self.tk.call(self._w, 'lastchild', tagOrId))

    def nextsibling(self, tagOrId):
        """Returns the next sibling item of the first item matching tagOrId.
           If tagOrId is the last child we return empty."""
        return self.tk.getint(self.tk.call(self._w, 'nextsibling', tagOrId))

    def prevsibling(self, tagOrId):
        """Returns the previous sibling item of the first item matching tagOrId.
           If tagOrId is the first child we return empty."""
        return self.tk.getint(self.tk.call(self._w, 'prevsibling', tagOrId))

    def parent(self, tagOrId):
        """Returns the parent item of the first item matching tagOrId. This
           command works for all items, also for the standard ones. It is
           therefore better to use this than 'cget id -parent' which is only
           supported for the new tkpath items."""
        return self.tk.getint(self.tk.call(self._w, 'parent', tagOrId))
    
    def lower(self,tagOrId,belowThis=None):
        """Movement is constrained to siblings. If reference tagOrId
           not given it defaults to first/last item of the root items children.
           Items which are not siblings to the reference tagOrId are silently
           ignored. Good or bad?"""
        self.tk.call(self._w, 'lower', tagOrId, belowThis)

    def raise_(self,tagOrId,aboveThis=None):
        """Movement is constrained to siblings. If reference tagOrId
           not given it defaults to first/last item of the root items children.
           Items which are not siblings to the reference tagOrId are silently
           ignored. Good or bad?"""
        self.tk.call(self._w, 'raise', tagOrId, aboveThis)

    def types(self):
        """List all item types defined in canvas."""
        return self.tk.splitlist(self.tk.call(self._w, 'types'))

    def create_group(self, **kw):
        """A group item is merely a placeholder for other items, similar to how a
           frame widget is a container for other widgets. It is a building block for
           the tree structure. Unlike other items, and unlike frame widgets, it
           doesn't display anything. It has no coordinates which is an additional
           difference. The root item is a special group item with id 0 and tags
           equal to "root". The root group can be configured like other items, but
           its -tags and -parent options are read only.
           Options set in a group are inherited by its children but they never override
           options explicitly set in children. This also applies to group items configured
           with a -style."""
        return self.tk.getint(self.tk.call(self._w, 'create', 'group',*(self._options({}, kw))))

    def create_path(self, *args, **kw):
        """Create path with coordinates x1,y1,x2,y2."""
        return self._create('path', args, kw)
        
    def create_circle(self, *args, **kw):
        """A plain circle item."""
        return self._create('circle', args, kw)

    def create_ellipse(self, *args, **kw):
        """An ellipse items"""
        return self._create('ellipse', args, kw)

    def create_prect(self, *args, **kw):
        """This is a rectangle item with optionally rounded corners."""
        return self._create('prect', args, kw)
    
    def create_pline(self, *args, **kw):
        """Makes a single-segment straight line."""
        return self._create('pline', args, kw)

    def create_polyline(self, *args, **kw):
        """Makes a multi-segment line with open ends."""
        return self._create('polyline', args, kw)

    def create_ppolygon(self, *args, **kw):
        """Makes a closed polygon."""
        return self._create('ppolygon', args, kw)

    def create_ptext(self, *args, **kw):
        """Displays text as expected. Note that the x coordinate marks the baseline
           of the text. Gradient fills are unsupported so far. Especially the font
           handling and settings will likely be developed further.
           Editing not implemented. The default font family and size is platform dependent."""
        return self._create('ptext', args, kw)

    def create_pimage(self, *args, **kw):
        """This displays an image in the canvas anchored nw. If -width or -height is
           nonzero then the image is scaled to this size prior to any affine transform."""
        return self._create('pimage', args, kw)

if __name__ == '__main__':
    from PIL import Image, ImageTk
    
    root = tk.Tk()

    tkp_canvas = Canvas(root,bg='white')
    
    antialias()
    #depixelize()

    tkp_canvas.pack(fill=tk.BOTH,expand=tk.YES)

    print(tkp_canvas.types())

    print(pixelalign())

    s1 = Style(tkp_canvas,stroke="#c8c8c8", fill="#e6e6e6")
    print(s1.cget('stroke'))

    #g1 = tkp_canvas.gradient_create('linear', stops=[(0.98,'gray'), (1.0,'white')])
    g1 = Gradient(tkp_canvas,'radial', stops=gradientstopsstyle('rainbow'))

    m1 = Matrix()
    m2 = Matrix()

    m1.scale(2).rotate(3.14/4)
    m2.move(-50,-300)

    m = m1*m2

    tkp_canvas.create_line(120,50,300,120)

    idc = tkp_canvas.create_prect(205,105,305,505,stroke='',matrix=Matrix().skewy(3.14/4),fill=g1,tags=('pera2'))
    #print(tkp_canvas.itemconfig(idc))
    #tkp_canvas.create_prect(200,100,300,500,stroke='red',matrix=Transform.scale(0.5),fill='white',tags=('pera2'))

    tkp_canvas.create_prect(50,75,100,125,fill=g1,tags=('pera2'),strokewidth=3)
    tkp_canvas.create_path("M 100 100 C 130 100 170 200 200 200", stroke='blue',endarrow=True,endarrowlength=7,endarrowwidth=4,strokewidth=2)
    tkp_canvas.create_prect(200,175,250,225,fill=g1,tags=('pera3'),strokewidth=3)
    #tkp_canvas.coords(id,"M 50  100 Q 80 20 140 100")

    tkp_canvas.create_path("M 100 100", stroke='blue',endarrow=True,endarrowlength=7,endarrowwidth=4,strokewidth=2)

    #tkp_canvas.create_circle(150,150,r=50,tags=('circle'))

    del g1

    image3 = ImageTk.PhotoImage(Image.new(mode="RGB",size=(300,300)))

    s = Surface(300,300)
    s.create('rectangle',100,100,200,200,fill='white')
    s.copy(image3)

    im = ImageTk.getimage(image3)
    im.convert('RGB').save("canvas.pdf","PDF",save_all=True)
    im.close()
    
    root.mainloop()
