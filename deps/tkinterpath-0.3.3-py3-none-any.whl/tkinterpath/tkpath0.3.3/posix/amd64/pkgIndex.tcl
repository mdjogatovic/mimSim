package ifneeded tkpath 0.3.3 \
  [list load [file join [pwd] libtkpath0.3.3[info sharedlibextension]] tkpath]
