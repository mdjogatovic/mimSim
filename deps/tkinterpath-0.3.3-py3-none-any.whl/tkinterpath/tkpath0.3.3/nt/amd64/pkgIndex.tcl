package ifneeded tkpath 0.3.3 \
  [list load [file join [pwd] tkpath033[info sharedlibextension]] tkpath]
